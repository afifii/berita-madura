<?php

// define( 'APPILO_COMPANION_DIR', plugin_dir_path( __FILE__ ) );
if (file_exists( XRIVER_CORE_DIR. '/admin/inc/admin.php')) {
    require_once XRIVER_CORE_DIR. '/admin/inc/admin.php';
}
