{
    "icons" : [
        "flaticon-digital-marketing",
        "flaticon-political-science",
        "flaticon-handshake",
        "flaticon-handshake-1",
        "flaticon-technology",
        "flaticon-news",
        "flaticon-news-1",
        "flaticon-ball",
        "flaticon-paw",
        "flaticon-bear",
        "flaticon-thunder",
        "flaticon-bookmark"
    ]
}
