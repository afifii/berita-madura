{
    "icons" : [
        "fal fa-long-arrow-right"
    ]
}
